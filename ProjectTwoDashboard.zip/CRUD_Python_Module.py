# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = username
        PASS = password 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
    def get_next_rec_num(self):
        try:
            #Find the document with the highest rec_num
            highest_rec = self.collection.find_one(sort=[("rec_num", -1)], projection={"rec_num":1})
            
            if highest_rec is None:
                return 1
        
            return int(highest_rec["rec_num"]) + 1
        
        except Exception as e:
            print (f"Error getting next record number: {e}")
            return 1
    
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None:
            doc_to_insert = data.copy()
            doc_to_insert["rec_num"] = self.get_next_rec_num()
            
            try:
                
                insert_result = self.collection.insert_one(doc_to_insert)  # data should be dictionary

                if insert_result.inserted_id:
                    print (f"Document successfully inserted with ID: {insert_result.inserted_id}")
                    return True
                else:
                    print("Insert failed -- no ID returned")
                    return False
            
            except Exception as e:
                print(f"Insert failed: {e}")
                return False
            
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 

    # Create method to implement the R in CRUD.
    def read (self, query=None):
        try:
            #Handle None query by passing empty dict
            query = query or {}    
            #Validate query is a dict
            if not isinstance(query, dict):
                print("Query must be a dictionary")
                return []
            
            #execute find query and convert cursor to list
            cursor = self.collection.find(query)
            
            #Convert cursor to list to return result
            results = list(cursor)
            
            #Log the number of docs found
            print(f"Found {len(results)} document(s)")
            return results
                      
        except Exception as e:
            print(f"Read failed: {e}")
            return []
        
        
    def update(self, query, update_data):
        if query is None or not isinstance(query, dict):
            raise Exception("Query parameter must be a valid dictionary.")
        if update_data is None or not isinstance(update_data, dict):
            raise Exception("Update data parameter must be a non-empty dictionary.")
        
        
        try:
            # uses update_many to update all docs matching query
            update_result = self.collection.update_many(query, update_data)
            
            #get count of modified docs
            modified_count = update_result.modified_count
            
            #Log result
            print(f"Update successful: {modified_count} document(s) modified")
            return modified_count
            
        except Exception as e:
            print(f"An error occurred during update: {e}")
            return -1
        
    def delete(self, query):
        if query is None or not isinstance(query, dict):
            raise Exception("Query parameter must be a valid dictionary.")
        
        # warn if trying to delete all documents
        if len(query) == 0:
            print("WARNING: Empty query will delete ALL documents in the collection!")
        query = query or input("insert correct query:")
        
        try:
            #use delete_many to remove all docs matching query
            delete_result = self.collection.delete_many(query)
            
            #Get the count of deleted docs
            deleted_count = delete_result.deleted_count
            
            #log result
            print(f"Delete operation successful: {deleted_count} document(s) deleted")
            
            return deleted_count
        
        
        except Exception as e:
            print(f"An error occurred during delete: {e}")
            return -1